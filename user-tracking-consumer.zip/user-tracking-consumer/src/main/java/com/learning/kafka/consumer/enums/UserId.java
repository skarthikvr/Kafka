package com.learning.kafka.consumer.enums;

public enum UserId {

    ABC123, ABC321, CBA123, CBA321, A1B2C3
}
