package org.learning.kafka.apps.v1;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import io.confluent.kafka.serializers.json.KafkaJsonSchemaSerializer;
import org.jboss.logging.Logger;

import java.util.Properties;


public class KafkaJsonJavaProducerV1Demo {

    private static Logger log = Logger.getLogger(KafkaJsonJavaProducerV1Demo.class);
    public static void main(String[] args) {

        Properties properties = new Properties();
        // normal producer
        properties.setProperty("bootstrap.servers", "127.0.0.1:9092");
        properties.setProperty("acks", "all");
        properties.setProperty("retries", "10");
        // avro part
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", "io.confluent.kafka.serializers.json.KafkaJsonSchemaSerializer");
        properties.setProperty("schema.registry.url", "http://127.0.0.1:8081");
        //log.info(properties);
        Producer<String, User> producer = new KafkaProducer<String, User>(properties);

        String topic = "user-json";

        // copied from avro examples

       User user = new User("pranabh","t",30);
        ProducerRecord<String, User> producerRecord = new ProducerRecord<String, User>(
                topic, user
        );

        System.out.println(user);
        producer.send(producerRecord, new Callback() {
            @Override
            public void onCompletion(RecordMetadata metadata, Exception exception) {
                if (exception == null) {
                    System.out.println(metadata);
                } else {
                    exception.printStackTrace();
                }
            }
        });

        producer.flush();
        producer.close();

    }
}
