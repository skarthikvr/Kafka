package org.learning.kafka.apps.v2;


import com.fasterxml.jackson.annotation.JsonProperty;

public class Address {

    @JsonProperty
    public String country;

    @JsonProperty
    public String state;

    public Address() {

    }
    public Address(String country, String state) {
        this.country = country;
        this.state = state;
    }

    @Override
    public String toString() {
        return "Address{" +
                "country='" + country + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
