package org.learning.kafka.apps.v2;


import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

public class KafkaJsonJavaProducerV2Demo {

    public static void main(String[] args) {
        Properties properties = new Properties();
        // normal producer
        properties.setProperty("bootstrap.servers", "127.0.0.1:9092");
        properties.setProperty("acks", "all");
        properties.setProperty("retries", "10");
        // avro part
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", "io.confluent.kafka.serializers.json.KafkaJsonSchemaSerializer");
        properties.setProperty("schema.registry.url", "http://127.0.0.1:8081");

        Producer<String, User> producer = new KafkaProducer<String, User>(properties);

        String topic = "user-json";

        // copied from avro examples
        Address address = new Address("India","Telangana");
        User user = new User("pranabh","t",30,address);

        ProducerRecord<String, User> producerRecord = new ProducerRecord<String, User>(
                topic, user
        );

        System.out.println(user);
        producer.send(producerRecord, new Callback() {
            @Override
            public void onCompletion(RecordMetadata metadata, Exception exception) {
                if (exception == null) {
                    System.out.println(metadata);
                } else {
                    exception.printStackTrace();
                }
            }
        });

        producer.flush();
        producer.close();

    }
}
