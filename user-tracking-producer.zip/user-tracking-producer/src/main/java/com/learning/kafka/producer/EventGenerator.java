package com.learning.kafka.producer;

import com.github.javafaker.Faker;
import com.learning.kafka.producer.enums.Color;
import com.learning.kafka.producer.enums.ProductType;
import com.learning.kafka.producer.enums.DesignType;
import com.learning.kafka.producer.enums.UserId;
import com.learning.kafka.producer.model.Event;
import com.learning.kafka.producer.model.Product;
import com.learning.kafka.producer.model.User;


public class EventGenerator {

    private Faker faker = new Faker();

    public Event generateEvent() {
        return Event.builder()
                .user(generateRandomUser())
                .product(generateRandomObject())
                .build();
    }

    private User generateRandomUser() {
        return User.builder()
                .userId(faker.options().option(UserId.class))
                .username(faker.name().lastName())
                .dateOfBirth(faker.date().birthday())
                .build();
    }

    private Product generateRandomObject() {
        return Product.builder()
                .color(faker.options().option(Color.class))
                .type(faker.options().option(ProductType.class))
                .designType(faker.options().option(DesignType.class))
                .build();
    }
}
