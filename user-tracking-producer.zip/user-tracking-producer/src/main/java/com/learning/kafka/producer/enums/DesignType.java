package com.learning.kafka.producer.enums;

public enum DesignType {

    NONE, SUITCASE, CAR, WARNING

}
