package com.learning.kafka.producer.enums;

public enum Color {

    GREEN, BLUE, PURPLE
}
