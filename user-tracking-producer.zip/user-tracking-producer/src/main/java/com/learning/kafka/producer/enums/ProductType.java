package com.learning.kafka.producer.enums;

public enum ProductType {

    TSHIRT, DESIGN,
}
