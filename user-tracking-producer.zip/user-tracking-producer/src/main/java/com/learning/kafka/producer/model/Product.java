package com.learning.kafka.producer.model;

import com.learning.kafka.producer.enums.Color;
import com.learning.kafka.producer.enums.DesignType;
import com.learning.kafka.producer.enums.ProductType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Product {

    private Color color;

    private ProductType type;

    private DesignType designType;
}
