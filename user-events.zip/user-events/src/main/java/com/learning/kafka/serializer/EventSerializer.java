package com.learning.kafka.serializer;

import com.learning.kafka.model.Event;
import org.apache.commons.lang3.SerializationUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;


public class EventSerializer implements Serializer<Event> {


    @Override public void configure(Map<String, ?> map, boolean b) {
    }
    @Override public byte[] serialize(String arg0, Event event) {
        byte[] data = SerializationUtils.serialize(event);
        return data;
    }
    @Override public void close() {
    }
}
