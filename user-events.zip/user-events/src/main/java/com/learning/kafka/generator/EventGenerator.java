package com.learning.kafka.generator;

import com.learning.kafka.model.Event;
import org.apache.kafka.common.utils.Utils;

import java.util.Random;

public class EventGenerator {

    public Event generateEvent(Integer i) {

        Event e = null;
        if ( i % 2 == 0) {
            e = new Event("view",10,"chrome","10.0.23.45");
        } else {
            e = new Event("click",13,"safari","10.0.23.49");
        }
        return e;
    }

    public Integer generateUserId() {
        Random rand = new Random();
        Integer i = Utils.toPositive(rand.nextInt());
        return i;
    }
}
