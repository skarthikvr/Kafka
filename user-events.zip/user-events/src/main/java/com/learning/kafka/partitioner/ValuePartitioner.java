package com.learning.kafka.partitioner;

import com.learning.kafka.model.Event;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

import java.util.Map;

public class ValuePartitioner implements Partitioner {

    @Override
    public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
        Integer partitionNumber = cluster.partitionCountForTopic(topic);

        Event event = SerializationUtils.deserialize(valueBytes);

        if (partitionNumber >= 2 && event.getBrowser().equals("chrome")) {
            partitionNumber = 0;
        } else {
            partitionNumber = 1;
        }
        return partitionNumber;
    }

    @Override
    public void close() {

    }

    @Override
    public void configure(Map<String, ?> map) {

    }
}
