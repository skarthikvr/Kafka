package com.learning.kafka.consumer;

import java.util.ArrayList;
import java.util.List;

public class CConsumerGroup {

    private final int numberOfConsumers;
    private final String groupId;
    private final String topic;
    private final String brokers;
    private List<ConsumerThread> consumers;

    // Limitation Per machine 2 threads , Given topic has 100 partitions
    // 5 machines each machine consumerGroup with 2 threads.

    // Consistent Hashing - 10 partitions -> 20 partitions

    // Assume I don't 5 have 5 machines
    // 1 machine 2 threads, 1st thread -> 50 partitions, 2nd thread -> 50 partitions
    public CConsumerGroup(String brokers, String groupId, String topic,
                                     int numberOfConsumers) {
        this.brokers = brokers;
        this.topic = topic;
        this.groupId = groupId;
        this.numberOfConsumers = numberOfConsumers;
        consumers = new ArrayList<>();
        for (int i = 0; i < this.numberOfConsumers; i++) {
            ConsumerThread ncThread =
                    new ConsumerThread(this.brokers, this.groupId, this.topic);
            consumers.add(ncThread);
        }
    }

    public void execute() {
        for (ConsumerThread ncThread : consumers) {
            Thread t = new Thread(ncThread);
            t.start();
        }
    }

    /**
     * @return the numberOfConsumers
     */
    public int getNumberOfConsumers() {
        return numberOfConsumers;
    }

    /**
     * @return the groupId
     */
    public String getGroupId() {
        return groupId;
    }

}
