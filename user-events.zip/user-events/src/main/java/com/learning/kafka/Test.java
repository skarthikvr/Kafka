package com.learning.kafka;

import com.learning.kafka.model.Event;

public class Test {

    public static void main(String[] args) throws InterruptedException {
        Event e1 = new Event("view",10,"chrome","10.0.23.45");
        Event e2 = new Event("view",10,"chrome","10.0.23.45");
        System.out.println(e1.hashCode());
        System.out.println(e2.hashCode());

    }


}
