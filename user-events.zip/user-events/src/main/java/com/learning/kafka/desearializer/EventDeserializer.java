package com.learning.kafka.desearializer;

import com.learning.kafka.model.Event;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.kafka.common.serialization.Deserializer;

import java.util.Map;

public class EventDeserializer implements Deserializer<Event> {
    @Override public void close() {
    }
    @Override public void configure(Map<String, ?> arg0, boolean arg1) {
    }
    @Override
    public Event deserialize(String arg0, byte[] data) {
        Event event = SerializationUtils.deserialize(data);
        return event;
    }
}
