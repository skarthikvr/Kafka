package com.learning.kafka.partitioner;

import com.learning.kafka.desearializer.EventDeserializer;
import com.learning.kafka.model.Event;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

import java.util.Map;

public class CustomPartitioner implements Partitioner {

    @Override
    public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
        Integer partitionNumber = cluster.partitionCountForTopic(topic);

        //Event event = SerializationUtils.deserialize(valueBytes);
        Integer userId = Integer.parseInt(((String)key).replace("user",""));
        if (userId % 2 == 0) {
            partitionNumber = 1;
        } else {
            partitionNumber = 0;
        }
        return partitionNumber;
    }

    @Override
    public void close() {

    }

    @Override
    public void configure(Map<String, ?> map) {

    }
}
