package com.learning.kafka.producer;

import com.learning.kafka.generator.EventGenerator;
import com.learning.kafka.model.Event;
import org.apache.kafka.clients.producer.*;
import org.apache.log4j.Logger;

import java.util.Properties;

import static java.lang.Thread.sleep;

public class CProducerWithValuePartitioner {

    static Logger log = Logger.getLogger(CProducer.class);
    public static void main(String[] args) throws InterruptedException {



        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "com.learning.kafka.serializer.EventSerializer");
        props.put(ProducerConfig.PARTITIONER_CLASS_CONFIG,"com.learning.kafka.partitioner.ValuePartitioner");

        Producer<String, Event> producer = new KafkaProducer<>(props);
        EventGenerator eventGenerator = new EventGenerator();
        String topic = "user-events";

        for(int i = 1; i <= 5; i++) {
            log.info("Generating event #" + i);

            Integer userId = eventGenerator.generateUserId();
            Event event = eventGenerator.generateEvent(userId);

            String key = "user"+userId;


            ProducerRecord<String, Event> producerRecord = new ProducerRecord<String,Event>(topic, key, event);

            log.info("Producing to Kafka the record: " + key + ":" + event);
            try {
                producer.send(producerRecord, new Callback() {
                    public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                        // executes every time a record is successfully sent or an exception is thrown
                        if (e == null) {
                            // the record was successfully sent
                            log.info("Received new metadata. \n" +
                                    "Topic:" + recordMetadata.topic() + "\n" +
                                    "Partition: " + recordMetadata.partition() + "\n" +
                                    "Offset: " + recordMetadata.offset() + "\n" +
                                    "Timestamp: " + recordMetadata.timestamp());
                        } else {
                            log.error("Error while producing", e);
                        }
                    }
                });
            } catch (Exception e) {
                log.error(e);
            }

            sleep(1000);
        }

        producer.close();
    }






}

