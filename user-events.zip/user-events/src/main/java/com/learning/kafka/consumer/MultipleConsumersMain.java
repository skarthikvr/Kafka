package com.learning.kafka.consumer;

import com.learning.kafka.producer.CProducerThread;

public final class MultipleConsumersMain {

    public static void main(String[] args) {

        String brokers = "localhost:9092";
        String groupId = "group01";
        String topic = "test-with-threads";
        int numberOfConsumer = 5;


        if (args != null && args.length > 4) {
            brokers = args[0];
            groupId = args[1];
            topic = args[2];
            numberOfConsumer = Integer.parseInt(args[3]);
        }


        CProducerThread producerThread = new CProducerThread(brokers, topic);
        Thread t1 = new Thread(producerThread);
        t1.start();


        CConsumerGroup consumerGroup =
                new CConsumerGroup(brokers, groupId, topic, numberOfConsumer);

        consumerGroup.execute();

        try {
            Thread.sleep(100000);
        } catch (InterruptedException ie) {

        }
    }
}