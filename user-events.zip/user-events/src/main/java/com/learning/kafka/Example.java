package com.learning.kafka;

public class Example {

    public static void main(String args[]) {
        Employee e = new Employee("Max", 22, 1, 100000.0);
        Employee e1 = new Employee("Max", 22, 1, 100000.0);

        String s = "Max";
        String s1 = "Max";

        System.out.println(e.equals(e1));
        System.out.println(e.hashCode());
        System.out.println(e.hashCode()%10);//Key.hashCode()%No_of_partitions.
        System.out.println(e1.hashCode()%10);

        System.out.println(s.equals(s1));
        System.out.println(s.hashCode());
        System.out.println(s1.hashCode());
    }
}
