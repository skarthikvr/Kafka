package com.learning.kafka.model;

import java.io.Serializable;
import java.util.Objects;

public class Event implements Serializable {

    private String eventType;

    private Integer userType;

    private String browser;

    private String ipAddress;

    public Event(String eventType, Integer userType, String browser, String ipAddress) {
        this.eventType = eventType;
        this.userType = userType;
        this.browser = browser;
        this.ipAddress = ipAddress;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Event event = (Event) o;
        return Objects.equals(eventType, event.eventType) &&
                Objects.equals(userType, event.userType) &&
                Objects.equals(browser, event.browser) &&
                Objects.equals(ipAddress, event.ipAddress);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventType, userType, browser, ipAddress);
    }

    @Override
    public String toString() {
        return "Event{" +
                "eventType='" + eventType + '\'' +
                ", userType=" + userType +
                ", browser='" + browser + '\'' +
                ", ipAddress='" + ipAddress + '\'' +
                '}';
    }
}
